This file contains simplenlg V 4.4.2

For information on simplenlg, please see
http://simplenlg.googlecode.com/


Version notes for v 4.4.2

** Latest version of SimpleNLG compiled with all bug fixes since August 2012.

Version notes for V 4.4:

** Latest version of SimpleNLG compiled with all bug fixes since June 2011.
** Added HTMLFormatter. This allows SimpleNLG output to be formatted in HTML tags.

N.B:

simplenlg-v4.4.3jar has been build for JVM's 1.6+ and higher.
